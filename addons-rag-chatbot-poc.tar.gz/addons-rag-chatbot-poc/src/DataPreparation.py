#%%
# Load environment variables
from dotenv import load_dotenv
load_dotenv()

#%% 
# toc 1. Import modules
#======================

# utils
import json
from datetime import datetime as dt
from omegaconf import OmegaConf

import boto3

from langchain_community.document_loaders import UnstructuredMarkdownLoader

from src.utils import get_collection, prepare_document

#%%
# toc 2. Main process
#=====================

def main():

    # Setup
    config = OmegaConf.load("params.yaml").data_preparation
    bedrock_client = boto3.client('bedrock-runtime')

    # Create/overwrite collection
    collection = get_collection(
        collection_name=config.collection_name,
        vector_db_path=f"./data/{config.collection_name}",
        embeddings_generator_model_id=config.embeddings_generator_model_id,
        bedrock_client=bedrock_client)
    
    if len(collection.get()['ids']) > 0:
        collection.delete(collection.get()['ids'])

    # Read addons metadata
    addons_metadata_file = 'data/addons_metadata.json'
    with open(addons_metadata_file) as f:
        addons_metadata = json.load(f)

    # Prepare documents
    now = dt.now()
    write_time = now.strftime("%Y-%m-%d %H:%M:%S.%f")
    write_ts = dt.timestamp(now)

    prepared_documents = []
    for addon in addons_metadata:

        document = UnstructuredMarkdownLoader(addon['enriched_description_file']).load()[0]

        prepared_documents += prepare_document(
            document=document,
            config_chunking_strategy=config.chunking_strategy,
            additional_metadata={
                'addon_name': addon['addon_name'], 
                'write_time': write_time, 
                'write_ts': write_ts}
            )
        print(f"Prepared documents for <{addon['addon_name']}>")

    # Add documents to vector database
    collection.add_documents(documents=prepared_documents)
    print(f"\nAll prepared documents added to <{config.collection_name}> collection")

# %%
if __name__ == "__main__":
    main()

