# Interface
import streamlit as st
from RAGChatbotEngine import create_rag_chatbot
from omegaconf import OmegaConf

def main():

    st.set_page_config(page_title="Addons RAG Chatbot")
    with st.sidebar:
        st.title('Addons RAG Chatbot')

    # Save bot instance in session_state
    if "bot" not in st.session_state:
        st.session_state.config = OmegaConf.load("params.yaml")
        st.session_state.bot = create_rag_chatbot(
            config_data_preparation=st.session_state.config.data_preparation,
            config_rag_chatbot_engine=st.session_state.config.rag_chatbot_engine)

    # Store LLM generated responses
    if "messages" not in st.session_state.keys():
        st.session_state.messages = \
            [{"role": "assistant", "content": st.session_state.bot.chat_message_history.messages[-1].content}]

    # Display chat messages
    for message in st.session_state.messages:
        with st.chat_message(message["role"]):
            st.write(message["content"])

    # User-provided prompt
    if input := st.chat_input():
        st.session_state.messages.append({"role": "user", "content": input})
        with st.chat_message("user"):
            st.write(input)

    # Generate a new response if last message is not from assistant
    if st.session_state.messages[-1]["role"] != "assistant":
        with st.chat_message("assistant"):
            with st.spinner("Generando respuesta..."):
                response = st.session_state.bot.chat_chain.invoke(
                    {"input": input},
                    {"configurable": {"session_id": "unused"}})
                st.write(response['answer'])
        message = {"role": "assistant", "content": response['answer']}
        st.session_state.messages.append(message)

if __name__ == '__main__':
    main()