#%%
# Load environment variables
from dotenv import load_dotenv
load_dotenv()

#%% 
# toc 1. Import modules
#======================

import json
from datetime import datetime as dt
from omegaconf import OmegaConf
from omegaconf.dictconfig import DictConfig

import boto3

from langchain_community.utilities import DuckDuckGoSearchAPIWrapper, GoogleSerperAPIWrapper
from langchain_community.document_loaders import AsyncHtmlLoader
from langchain_community.document_transformers import Html2TextTransformer
from langchain_core.documents.base import Document

from src.utils import get_collection, prepare_document

# %%
# toc 2. Define functions
#=========================

def get_web_search_config(platform: str, template: DictConfig) -> dict:

    web_search_config_str = json.dumps(
        OmegaConf.to_container(template), ensure_ascii=False).replace('<platform>', platform)

    web_search_config = json.loads(web_search_config_str)
    web_search_config['main_topic'] = web_search_config['main_topic'].capitalize()

    return web_search_config 

def get_web_search_results_duckduck(web_search_query: str, config_search_engine: DictConfig) -> list[dict]:

    wrapper = DuckDuckGoSearchAPIWrapper(
        region=config_search_engine.region, 
        time=config_search_engine.time)
    
    search_results = wrapper.results(web_search_query, max_results=config_search_engine.max_results)

    return search_results

def get_web_search_results_serper(web_search_query: str, config_search_engine: DictConfig) -> list[dict]:
    
    wrapper = GoogleSerperAPIWrapper(
        gl=config_search_engine.country_cd, 
        hl=config_search_engine.language_cd, 
        k=config_search_engine.max_results)
    
    search_results = wrapper.results(web_search_query)['organic']

    return search_results

def get_scrapped_content(search_results: list) -> list[Document]:
    
    urls = [item['link'] for item in search_results]
    loader = AsyncHtmlLoader(urls)
    docs = loader.load()

    html2text = Html2TextTransformer()
    scrapped_content = html2text.transform_documents(docs)

    return scrapped_content

def get_web_content(web_search_query: str, config_search_engine: DictConfig) -> list[Document]:

    if config_search_engine.provider == "serper":
        search_results = get_web_search_results_serper(
            web_search_query, config_search_engine)  
    elif config_search_engine.provider == "duckduck":
        search_results = get_web_search_results_duckduck(
            web_search_query, config_search_engine)
    else: 
        raise ValueError(f"'{config_search_engine.provider}' is not a valid provider")
        
    scrapped_content = get_scrapped_content(search_results)

    return scrapped_content


# %%
# toc 3. Main process
#=====================

#%%
def main():

    # Setup
    bedrock_client = boto3.client('bedrock-runtime')
    config = OmegaConf.load("params.yaml").web_content_collection

    # Create/overwrite collection
    collection = get_collection(
        collection_name=config.collection_name,
        vector_db_path=f"./data/{config.collection_name}",
        embeddings_generator_model_id=config.embeddings_generator_model_id,
        bedrock_client=bedrock_client)
    
    if len(collection.get()['ids']) > 0:
        collection.delete(collection.get()['ids'])

    # Read addons metadata file
    addons_metadata_file = 'data/addons_metadata.json'
    with open(addons_metadata_file) as f:
        addons_metadata = json.load(f)

    # Collect web content
    for addon in addons_metadata:

        print(f"\n\n<{addon['addon_name']}>")

        for platform in addon['platforms']:

            web_search_config = get_web_search_config(
                platform=platform, 
                template=OmegaConf.load(config.web_search_template_path))
            
            for topic in web_search_config['web_search_topics']:

                print(topic)

                n_available_documents = \
                    len(collection.get(where={'search_question': topic['search_question']})['ids'])
                
                if n_available_documents > 0:

                    print(f"Web content collection skipped. {n_available_documents} already available documents "+\
                        f"for search_question '{topic['search_question']}'.")
                    
                else:

                    # Get web content
                    web_content = get_web_content(
                        web_search_query=topic['web_search_query'], 
                        config_search_engine=config.search_engine)
                    
                    # Prepare documents
                    now = dt.now()
                    write_time = now.strftime("%Y-%m-%d %H:%M:%S.%f")
                    write_ts = dt.timestamp(now)
                    additional_metadata = {
                        'platform': platform,
                        'search_question': topic['search_question'],
                        'web_search_query': topic['web_search_query'],
                        'write_time': write_time,
                        'write_ts': write_ts
                    }
                    web_content_prepared = []
                    for document in web_content:
                        web_content_prepared += prepare_document(
                            document=document,
                            config_chunking_strategy=config.chunking_strategy,
                            additional_metadata=additional_metadata)
                    
                    # Write documents to vector db
                    collection.add_documents(documents=web_content_prepared)
                    n_available_documents = \
                        len(collection.get(where={'search_question': topic['search_question']})['ids'])
                    print(f"{n_available_documents} added documents for search_question '{topic['search_question']}'.")

# %%
if __name__ == "__main__":
    main()
