#%%
from src.RAGChatbotEngine import create_rag_chatbot
from omegaconf import OmegaConf
import pandas as pd
import logging

#%%
# Configure logging
#-------------------
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - \n%(message)s')
logger = logging.getLogger()
logger.setLevel(logging.INFO)

#%%
def main():

    # Setup
    config = OmegaConf.load("params.yaml")

    file_name = config.evaluation_data_generation.raw_evaluation_data_file
    input_file_path = f"data/evaluation_data_raw/{file_name}"
    output_file_path = f"data/evaluation_data_generated/{file_name}"

    # Read data
    evaluation_user_messages_df = pd.read_csv(input_file_path)

    # Generate evaluation dataset
    logger.info('***********EVALUATION DATA GENERATION STARTED**************')
    evaluation_df = pd.DataFrame()
    conversation_ids = evaluation_user_messages_df.conversation_id.unique()

    for conversation_id in conversation_ids:

        chatbot = create_rag_chatbot(
            config_data_preparation=config.data_preparation,
            config_rag_chatbot_engine=config.rag_chatbot_engine)
        
        user_messages = evaluation_user_messages_df\
            .loc[evaluation_user_messages_df.conversation_id == conversation_id].user_message.unique()
        
        for user_message in user_messages:

            result = chatbot.chat_chain.invoke(
                {"input": user_message},
                {"configurable": {"session_id": f"{file_name.rstrip('.csv')}_{conversation_id}"}})
            
            evaluation_df = pd.concat(
                [
                    evaluation_df, 
                    pd.DataFrame({
                        'conversation_id': conversation_id,
                        'user_message': user_message,
                        'chat_history': [result['chat_history']],
                        'context': [result['context']],
                        'answer': result['answer']})
                ]
            )
    evaluation_df.reset_index(drop=True, inplace=True)    

    # Write data
    evaluation_df.to_csv(output_file_path, index=False)
    logger.info("***********EVALUATION DATA GENERATION FINISHED**************")
    logger.info(f">>Evaluation data generated at {output_file_path}")

# %%
if __name__ == "__main__":
    main()