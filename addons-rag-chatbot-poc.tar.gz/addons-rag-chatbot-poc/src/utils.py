from omegaconf.dictconfig import DictConfig
from omegaconf import OmegaConf

from langchain_community.llms import Bedrock
from langchain_community.chat_models import BedrockChat
from langchain_openai import ChatOpenAI

from langchain_community.vectorstores import Chroma
from langchain_community.embeddings import BedrockEmbeddings
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_core.documents.base import Document
from typing import Union

def get_collection(collection_name: str, vector_db_path: str, embeddings_generator_model_id: str, 
                   bedrock_client) -> Chroma:

    embeddings_generator = BedrockEmbeddings(
        model_id=embeddings_generator_model_id,
        client=bedrock_client)
    
    collection = Chroma(collection_name=collection_name, 
                        embedding_function=embeddings_generator, 
                        persist_directory=vector_db_path)
    
    return collection 

def prepare_document(document: Document, config_chunking_strategy: DictConfig,
                      additional_metadata: Union[dict, None] = None) -> list[Document]:

    # Include additional metadata
    if additional_metadata:
        for key in additional_metadata:
            document.metadata[key] = additional_metadata[key]

    # Split documents
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=config_chunking_strategy.chunk_size,
        chunk_overlap=config_chunking_strategy.chunk_overlap
        )
    
    splitted_documents = text_splitter.split_documents([document])

    return splitted_documents

def get_llm(config_llm: DictConfig) -> Union[Bedrock, BedrockChat, ChatOpenAI]:

    if config_llm.provider == 'bedrock':

        if config_llm.model_id not in ['anthropic.claude-3-sonnet-20240229-v1:0']:
            llm = Bedrock(
                model_id=config_llm.model_id,
                model_kwargs=OmegaConf.to_container(config_llm.model_params))
        else:
            llm = BedrockChat(
                model_id=config_llm.model_id,
                model_kwargs=OmegaConf.to_container(config_llm.model_params))
            
    elif config_llm.provider == 'openai':
        llm = ChatOpenAI(
            model=config_llm.model_id, 
            temperature=config_llm.model_params.temperature,
            max_tokens=config_llm.model_params.max_tokens,
            model_kwargs=OmegaConf.to_container(config_llm.model_params.model_kwargs))

    return llm