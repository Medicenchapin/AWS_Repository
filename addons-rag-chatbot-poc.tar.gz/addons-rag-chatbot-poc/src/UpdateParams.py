#%%
from dotenv import load_dotenv
import os
from hydra import compose, initialize_config_dir
from omegaconf import OmegaConf

#%%
def update_params(config_dir:str, params_file:str, config_name:str="config") -> None:

    with initialize_config_dir(version_base=None, config_dir=config_dir):
        config = compose(config_name=config_name)

    with open(params_file, "w") as f:
        OmegaConf.save(config=config, f=f)

#%%
if __name__ == "__main__":
    load_dotenv()
    update_params(
        config_dir=f"{os.environ.get('ROOT_WORKING_DIRECTORY')}/conf",
        params_file=f"{os.environ.get('ROOT_WORKING_DIRECTORY')}/params.yaml"
    )

# %%
