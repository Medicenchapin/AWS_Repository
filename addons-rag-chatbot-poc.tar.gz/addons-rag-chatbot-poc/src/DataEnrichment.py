#%%
# Load environment variables
from dotenv import load_dotenv
load_dotenv()

#%% 
# toc 1. Import modules
#======================

import os
import json
import boto3

from omegaconf import OmegaConf
from omegaconf.dictconfig import DictConfig

from langchain_community.vectorstores import Chroma
from langchain.chains.summarize import load_summarize_chain
from langchain_core.prompts import PromptTemplate
from langchain_core.documents.base import Document

from src.utils import get_collection, get_llm
from src.WebContentCollection import get_web_search_config

# %%
# toc 2. Define functions
#=========================

# toc --2.2 Low level 
#----------------------

def get_stuff_summary_langchain(search_question: str, collection: Chroma, config_data_enrichment: DictConfig, 
                                bedrock_client=None) -> Document:

    search_results = collection.similarity_search(
        query=search_question, 
        filter={'search_question': search_question},
        k=config_data_enrichment.summarization_approach.max_results)

    prompt_template = config_data_enrichment.summarization_approach.prompt.template
    prompt = PromptTemplate(
        template=prompt_template,
        input_variables = ["text","question"])
    
    stuff_chain = load_summarize_chain(
        llm=get_llm(config_data_enrichment.summarization_LLM),
        chain_type='stuff',
        prompt=prompt, 
        document_variable_name='text')

    summary = stuff_chain.invoke(
        {'input_documents': search_results,
        'question': search_question})['output_text']
    
    # Drop undesired prefixes
    for prefix in ["\n","\n\n"]: 
        summary = summary.removeprefix(prefix)

    summary_document = Document(
        page_content=summary,
        metadata={'source': list(set([result.metadata['source'] for result in search_results]))})

    return summary_document

def get_mapreduce_summary_langchain(search_question: str, collection: Chroma, config_data_enrichment: DictConfig, 
                                    bedrock_client=None) -> Document:
    
    search_results = collection.similarity_search(
        query=search_question, 
        filter={'search_question': search_question},
        k=config_data_enrichment.summarization_approach.max_results)

    map_prompt = PromptTemplate(
        template=config_data_enrichment.summarization_approach.prompt.mapreduce_map.template,
        input_variables=["text","question"])
    combine_prompt = PromptTemplate(
        template=config_data_enrichment.summarization_approach.prompt.mapreduce_reduce.template,
        input_variables=["text","question"])

    map_reduce_chain = load_summarize_chain(
        llm=get_llm(config_data_enrichment.summarization_LLM),
        chain_type="map_reduce",
        map_prompt=map_prompt,
        combine_prompt=combine_prompt,
        return_intermediate_steps=True
    )

    summary = map_reduce_chain.invoke(
        {'input_documents': search_results,
         'question': search_question})
    
    # Drop undesired prefixes
    for prefix in ["\n","\n\n"]: 
        summary['output_text'] = summary['output_text'].removeprefix(prefix)
        summary['intermediate_steps'] = \
            [intermediate_step.removeprefix(prefix) for intermediate_step in summary['intermediate_steps']]   
    
    summary_document = Document(
        page_content=summary['output_text'],
        metadata={
            'source': list(set([result.metadata['source'] for result in search_results])),
            'intermediate_summaries': summary['intermediate_steps']
        }
    )

    return summary_document

def generate_text_bedrock(prompt: str, model_id: str, model_params: str, bedrock_client) -> str:

    if model_id in ["amazon.titan-text-express-v1"]:
        body = json.dumps({"inputText": prompt, "textGenerationConfig": model_params})

    elif model_id in ['ai21.j2-ultra-v1']:
        body_dict = model_params.copy()
        body_dict['prompt'] = prompt
        body = json.dumps(body_dict)

    elif model_id in ["anthropic.claude-3-sonnet-20240229-v1:0"]:
        body_dict = model_params.copy()
        body_dict['anthropic_version'] = "bedrock-2023-05-31"
        body_dict['messages'] = [{
            "role": "user",
            "content": [{"type": "text", "text": prompt}]
            }]
        body = json.dumps(body_dict)

    response = bedrock_client.invoke_model(
        body=body, modelId=model_id,
        accept="application/json", contentType="application/json")
    response_body = json.loads(response.get("body").read())

    if model_id in ["amazon.titan-text-express-v1"]:
        answer = response_body.get("results")[0].get("outputText")

    elif model_id in ['ai21.j2-ultra-v1']:
        answer = response_body.get("completions")[0].get('data').get("text")

    elif model_id in ["anthropic.claude-3-sonnet-20240229-v1:0"]:
        answer = response_body.get("content")[0].get('text')

    # Drop undesired prefixes
    for prefix in ["\n","\n\n"]: 
        answer = answer.removeprefix(prefix)

    return answer

def get_stuff_summary_boto3(search_question: str, collection: Chroma, config_data_enrichment: DictConfig, 
                            bedrock_client) -> Document:

    search_results = collection.similarity_search(
        query=search_question, 
        filter={'search_question': search_question},
        k=config_data_enrichment.summarization_approach.max_results)

    text = '\n\n'.join([search_result.page_content for search_result in search_results])

    prompt_template = config_data_enrichment.summarization_approach.prompt.template
    prompt=prompt_template.format(question=search_question, text=text)

    summary = generate_text_bedrock(
        prompt=prompt,
        model_id=config_data_enrichment.summarization_LLM.model_id,
        model_params=OmegaConf.to_container(config_data_enrichment.summarization_LLM.model_params),
        bedrock_client=bedrock_client)
    
    summary_document = Document(
        page_content=summary,
        metadata={'source': list(set([result.metadata['source'] for result in search_results]))})

    return summary_document

def get_mapreduce_summary_boto3(search_question: str, collection: Chroma, config_data_enrichment: DictConfig, 
                                bedrock_client) -> Document:
    
    search_results = collection.similarity_search(
        query=search_question, 
        filter={'search_question': search_question},
        k=config_data_enrichment.summarization_approach.max_results)

    # Map stage
    map_intermediate_summaries = []
    for document in search_results:

        map_prompt = config_data_enrichment.summarization_approach.prompt.mapreduce_map.template\
            .format(question=search_question, text=document.page_content)
        
        map_summary = generate_text_bedrock(
            prompt=map_prompt,
            model_id=config_data_enrichment.summarization_LLM.model_id,
            model_params=OmegaConf.to_container(config_data_enrichment.summarization_LLM.model_params),
            bedrock_client=bedrock_client)

        map_intermediate_summaries.append(map_summary)

    # Reduce stage
    map_intermediate_summaries_text = '\n\n'.join(map_intermediate_summaries)
    
    reduce_prompt = config_data_enrichment.summarization_approach.prompt.mapreduce_reduce.template\
        .format(question=search_question, text=map_intermediate_summaries_text)
    
    reduce_summary = generate_text_bedrock(
        prompt=reduce_prompt,
        model_id=config_data_enrichment.summarization_LLM.model_id,
        model_params=OmegaConf.to_container(config_data_enrichment.summarization_LLM.model_params),
        bedrock_client=bedrock_client)

    summary_document = Document(
        page_content=reduce_summary,
        metadata={
            'source': list(set([result.metadata['source'] for result in search_results])),
            'intermediate_summaries': map_intermediate_summaries
        }
    )

    return summary_document

def add_content(input_content: str, content: str = None, title: str = None, source_list: list[str] = None, 
                title_level: int = 1) -> str:

    if title is None and content is None:
        print("No additional content is added to output_file")

    updated_content = input_content
    if title:
        updated_content += f"\n\n{'#'*title_level} {title}"
    if content:
        updated_content += f"\n\n{content}"
    if source_list:
        updated_content += f"\n\n**Fuente:**"
        for source in source_list:
            updated_content += f"\n- {source}"

    return updated_content


# toc --2.2 Upper level 
#-----------------------

def get_summary(search_question: str, collection: Chroma, config_data_enrichment: DictConfig,
                bedrock_client) -> Document:
        
    summarization_strategies = {}
    summarization_strategies['stuff'] = {}
    summarization_strategies['stuff']['boto3'] = get_stuff_summary_boto3
    summarization_strategies['stuff']['langchain'] = get_stuff_summary_langchain
    summarization_strategies['mapreduce'] = {}
    summarization_strategies['mapreduce']['boto3'] = get_mapreduce_summary_boto3
    summarization_strategies['mapreduce']['langchain'] = get_mapreduce_summary_langchain
     
    try: 
        summarization_strategy = summarization_strategies\
            [config_data_enrichment.summarization_approach.name][config_data_enrichment.summarization_approach.tool]

        summary = summarization_strategy(
            search_question, 
            collection, 
            config_data_enrichment=config_data_enrichment, 
            bedrock_client=bedrock_client)
              
    except Exception as e:
        print(f"summarization_strategy is not valid. {e}")
        raise e

    return summary

def create_content(content_list: list[dict], main_title: str, main_title_level: int = 1, 
                   content_title_level: int = 2, topic_title_level: int = 3, include_source : bool = False) -> str:

    # Add main title
    md_content = add_content(
        input_content='',
        title=main_title,
        title_level=main_title_level
        )

    for content in content_list:

        # Add content title
        md_content = add_content(
            input_content=md_content,
            title=content['main_topic'],
            title_level=content_title_level
            )
        
        # Add topics
        for topic in content['web_search_topics']:
            md_content = add_content(
                input_content=md_content,
                title=topic['title'],
                content=topic['summary_document'].page_content,
                source_list=topic['summary_document'].metadata['source'] if include_source else None,
                title_level=topic_title_level
                )
            
    return md_content.lstrip('\n')

def add_content_to_document(input_document_path: str, output_document_path: str, content: str) -> None:

    # Read input document
    with open(input_document_path, 'r', encoding='utf-8') as f:
        input_document_content = f.read()

    # Add content
    updated_content = add_content(
        input_content=input_document_content,
        content=content)
            
    # Write updated document
    os.makedirs(os.path.dirname(output_document_path), exist_ok=True)
    with open(output_document_path, 'w+', encoding='utf-8') as f:
        f.write(updated_content)

    print(f"Updated document at '{output_document_path}'")


# %%
# toc 3. Main process
#=====================

#%%
def main():

    # Setup
    config = OmegaConf.load("params.yaml")
    bedrock_client = boto3.client('bedrock-runtime')

    collection = get_collection(
        collection_name=config.web_content_collection.collection_name,
        vector_db_path=f"./data/{config.web_content_collection.collection_name}",
        embeddings_generator_model_id = config.web_content_collection.embeddings_generator_model_id,
        bedrock_client=bedrock_client)

    # Read addons metadata file
    addons_metadata_file = 'data/addons_metadata.json'
    with open(addons_metadata_file) as f:
        addons_metadata = json.load(f)

    # Enrich raw documents
    for addon in addons_metadata:

        print(f"\n\n<{addon['addon_name']}>")

        # Get web search summaries for each platform
        web_search_summaries = []
        for platform in addon['platforms']:

            web_search_config = get_web_search_config(
                    platform=platform, 
                    template=OmegaConf.load(config.web_content_collection.web_search_template_path))
            
            web_search_summary = {'main_topic': web_search_config['main_topic']}
            web_search_summary['web_search_topics'] = []

            for topic in web_search_config['web_search_topics']:
                print(topic)
                web_search_topic_summary = get_summary(
                    search_question=topic['search_question'],
                    collection=collection,  
                    config_data_enrichment=config.data_enrichment,
                    bedrock_client=bedrock_client
                )
                web_search_summary['web_search_topics'].append(
                    {'title':topic['title'],'summary_document': web_search_topic_summary})

            web_search_summaries.append(web_search_summary)
            
        # Add web search summaries to document
        new_content = create_content(
            content_list = web_search_summaries,
            main_title='Descripción de plataformas',
            include_source=True)
        add_content_to_document(
            input_document_path=addon['raw_description_file'],
            output_document_path=addon['enriched_description_file'],
            content=new_content)

# %%
if __name__ == "__main__":
    main()