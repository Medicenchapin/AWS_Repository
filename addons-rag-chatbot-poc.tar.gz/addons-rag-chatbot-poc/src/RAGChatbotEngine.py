#%%
# Load environment variables
import os
import sys
# __import__('pysqlite3')
# import sys
# sys.modules['sqlite3'] = sys.modules.pop('pysqlite3')

from dotenv import load_dotenv
load_dotenv()
sys.path.append(f"{os.getenv('ROOT_WORKING_DIRECTORY')}/src")



#%%
# toc 1. Import modules
#======================

import logging
import pprint as pp
import boto3
from abc import ABC, abstractmethod

from omegaconf import OmegaConf
from omegaconf.dictconfig import DictConfig

from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain.memory import ChatMessageHistory
from langchain_core.runnables.history import RunnableWithMessageHistory
from langchain.chains.combine_documents import create_stuff_documents_chain
from langchain.chains import create_history_aware_retriever, create_retrieval_chain
from langchain_core.runnables import RunnablePassthrough
from langchain_core.messages.human import HumanMessage
from langchain_core.messages.ai import AIMessage
from langchain_core.output_parsers.string import StrOutputParser
from langchain_core.vectorstores import VectorStoreRetriever
from utils import get_collection, get_llm

#%%
# Configure logging
#-------------------
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - \n%(message)s')
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# %%
# toc 2. Define classes
#======================

CHAT_MESSAGES_TO_SUMMARIZE = 4
CHAT_MESSAGES_TO_DROP = 2

# toc --2.1 Chatbot interface
#============================

class RAGChatbot(ABC):

    def __init__(self, config_data_preparation: DictConfig, config_rag_chatbot_engine: DictConfig):
        self.chat_llm_model_id = self.set_chat_llm_model_id(config_rag_chatbot_engine.chat_LLM)
        self.chat_llm = get_llm(config_rag_chatbot_engine.chat_LLM)
        self.chat_message_history = self.set_chat_message_history(config_rag_chatbot_engine.first_ai_msg)
        self.max_stored_messages = self.set_max_stored_messages(config_rag_chatbot_engine.max_stored_messages)
        self.retriever = self.set_retriever(config_data_preparation, config_rag_chatbot_engine)
        self.prompts = self.set_prompts(config_rag_chatbot_engine.prompts)
        self.chat_chain = self.set_chat_chain()

    def set_chat_llm_model_id(self, config_chat_LLM) -> str:
        return config_chat_LLM.model_id

    def set_chat_message_history(self, first_ai_msg: str) -> ChatMessageHistory:
        chat_message_history = ChatMessageHistory()
        chat_message_history.add_user_message("Hola")
        chat_message_history.add_ai_message(first_ai_msg)

        return chat_message_history
    
    def set_retriever(self, config_data_preparation: DictConfig, 
                      config_rag_chatbot_engine: DictConfig) -> VectorStoreRetriever:
        
        bedrock_client = boto3.client('bedrock-runtime')

        collection = get_collection(
            collection_name=config_data_preparation.collection_name,
            vector_db_path=f"./data/{config_data_preparation.collection_name}",
            embeddings_generator_model_id=config_data_preparation.embeddings_generator_model_id,
            bedrock_client=bedrock_client)

        retriever = collection.as_retriever(
            search_type="similarity",
            search_kwargs={"k": config_rag_chatbot_engine.max_retrieved_documents})
        
        return retriever
    
    def set_max_stored_messages(self, value: int) -> int:
        if value % 2 == 0:
            return value
        else:
            raise ValueError(f"max_stored_messages = {value} not valid. "+\
                             "max_stored_messages must be an even number or -1 for no storage limit.")

    @abstractmethod
    def set_prompts(self):
        pass
    
    @abstractmethod
    def set_chat_chain(self):
        pass

# toc --2.2 Chatbot types
#=========================

class RAGChatbotWithFullMemory(RAGChatbot):
        
    def set_prompts(self, config_prompts: DictConfig) -> dict[ChatPromptTemplate]:

        bot_instructions_prompt = ChatPromptTemplate.from_messages(
            [
                (
                    "system",
                    config_prompts.bot_instructions.template,
                ),
                MessagesPlaceholder(variable_name="chat_history"),
                ("human", "{input}"),
            ]
        )

        query_transformation_prompt = ChatPromptTemplate.from_messages(
            [
                (
                    "system",
                    config_prompts.query_transformation.template,
                ),
                MessagesPlaceholder(variable_name="chat_history"),
                ("human", "{input}"),
            ]
        )

        prompts = {
            'bot_instructions': bot_instructions_prompt,
            'query_transformation': query_transformation_prompt
        }

        return prompts

    def set_chat_chain(self):

        question_answer_chain = create_stuff_documents_chain(
            self.chat_llm, 
            self.prompts['bot_instructions'])

        history_aware_retriever = create_history_aware_retriever(
            self.chat_llm, self.retriever, self.prompts['query_transformation']
        )

        rag_chain = create_retrieval_chain(history_aware_retriever, question_answer_chain)
        
        conversational_rag_chain = RunnableWithMessageHistory(
            rag_chain,
            lambda session_id: self.chat_message_history,
            input_messages_key="input",
            history_messages_key="chat_history",
            output_messages_key="answer",
        )

        return conversational_rag_chain   

class RAGChatbotWithMsgDropping(RAGChatbot):    

    def set_prompts(self, config_prompts: DictConfig) -> dict[ChatPromptTemplate]:

        bot_instructions_prompt = ChatPromptTemplate.from_messages(
            [
                (
                    "system",
                    config_prompts.bot_instructions.template,
                ),
                MessagesPlaceholder(variable_name="chat_history"),
                ("human", "{input}"),
            ]
        )

        query_transformation_prompt = ChatPromptTemplate.from_messages(
            [
                (
                    "system",
                    config_prompts.query_transformation.template,
                ),
                MessagesPlaceholder(variable_name="chat_history"),
                ("human", "{input}"),
            ]
        )

        prompts = {
            'bot_instructions': bot_instructions_prompt,
            'query_transformation': query_transformation_prompt
        }

        return prompts

    def set_chat_chain(self):

        question_answer_chain = create_stuff_documents_chain(
            self.chat_llm, 
            self.prompts['bot_instructions'])

        history_aware_retriever = create_history_aware_retriever(
            self.chat_llm, self.retriever, self.prompts['query_transformation']
        )

        rag_chain = create_retrieval_chain(history_aware_retriever, question_answer_chain)
        
        conversational_rag_chain = RunnableWithMessageHistory(
            rag_chain,
            lambda session_id: self.chat_message_history,
            input_messages_key="input",
            history_messages_key="chat_history",
            output_messages_key="answer",
        )

        chain_with_message_dropping = (
                RunnablePassthrough.assign(messages_summarized=self.drop_old_messages)
                | conversational_rag_chain
            )

        return chain_with_message_dropping
    
    def drop_old_messages(self, chain_input) -> bool:

        stored_messages = self.chat_message_history.messages
        logger.info('===========<<limit message storage dropping old messages>>===========')
        logger.info(f'\n>> stored_messages: {len(stored_messages)}')
        logger.info(f'{pp.pformat(stored_messages)}')

        if len(stored_messages) <= self.max_stored_messages:
            return False
        
        messages_to_drop = stored_messages[:CHAT_MESSAGES_TO_DROP]
        logger.info(f'\n>> messages_to_drop: {len(messages_to_drop)}')
        logger.info(f'{pp.pformat(messages_to_drop)}')
        self.chat_message_history.clear()

        for message in stored_messages[CHAT_MESSAGES_TO_DROP:]:
            self.chat_message_history.add_message(message)
        logger.info(f'\n>> updated_stored_messages: {len(self.chat_message_history.messages)}')
        logger.info(f'{pp.pformat(self.chat_message_history.messages)}')

        return True

class RAGChatbotWithMsgSummarization(RAGChatbot):

    def set_prompts(self, config_prompts: DictConfig) -> dict[ChatPromptTemplate]:

        bot_instructions_prompt = ChatPromptTemplate.from_messages(
            [
                (
                    "system",
                    config_prompts.bot_instructions.template,
                ),
                MessagesPlaceholder(variable_name="chat_history"),
                ("human", "{input}"),
            ]
        )

        query_transformation_prompt = ChatPromptTemplate.from_messages(
            [
                (
                    "system",
                    config_prompts.query_transformation.template,
                ),
                MessagesPlaceholder(variable_name="chat_history"),
                ("human", "{input}"),
            ]
        )

        chat_summarization_prompt = ChatPromptTemplate.from_messages(
            [
                (
                    "system",
                    config_prompts.chat_summarization.template,
                ),
                MessagesPlaceholder(variable_name="chat_history"),
            ]
        )

        prompts = {
            'bot_instructions': bot_instructions_prompt,
            'query_transformation': query_transformation_prompt,
            'chat_summarization': chat_summarization_prompt
        }

        return prompts

    def set_chat_chain(self):

        question_answer_chain = create_stuff_documents_chain(
            self.chat_llm, 
            self.prompts['bot_instructions'])

        history_aware_retriever = create_history_aware_retriever(
            self.chat_llm, self.retriever, self.prompts['query_transformation']
        )

        rag_chain = create_retrieval_chain(history_aware_retriever, question_answer_chain)
        
        conversational_rag_chain = RunnableWithMessageHistory(
            rag_chain,
            lambda session_id: self.chat_message_history,
            input_messages_key="input",
            history_messages_key="chat_history",
            output_messages_key="answer",
        )

        if self.chat_llm_model_id in ["anthropic.claude-3-sonnet-20240229-v1:0"]:
            chain_with_summarization = (
                RunnablePassthrough.assign(messages_summarized=self.summarize_old_messages_A)
                | conversational_rag_chain
            )
        else:
            chain_with_summarization = (
                RunnablePassthrough.assign(messages_summarized=self.summarize_old_messages_B)
                | conversational_rag_chain
            )

        return chain_with_summarization
        
    def summarize_old_messages_A(self, chain_input) -> bool:

        stored_messages = self.chat_message_history.messages
        logger.info('===========<<limit message storage with summarization>>===========')
        logger.info(f'\n>> stored_messages: {len(stored_messages)}')
        logger.info(f'{pp.pformat(stored_messages)}')

        if len(stored_messages) <= self.max_stored_messages:
            return False
        
        prompt_template = ChatPromptTemplate.from_messages([("user", "{question}")])
        summarization_chain = prompt_template | self.chat_llm | StrOutputParser()

        messages_to_summarize = stored_messages[:CHAT_MESSAGES_TO_SUMMARIZE]

        logger.info(f'\n>> messages_to_summarize: {len(messages_to_summarize)}')
        logger.info(f'{pp.pformat(messages_to_summarize)}')

        reformated_prompt = self.reformat_chat_summarization(messages_to_summarize)
        summary_message = summarization_chain.invoke({"question": reformated_prompt})
        
        self.chat_message_history.clear()
        self.chat_message_history.add_user_message("Resume nuestra conversación")
        self.chat_message_history.add_ai_message(summary_message)

        for message in stored_messages[CHAT_MESSAGES_TO_SUMMARIZE:]:
            self.chat_message_history.add_message(message)
        logger.info(f'\n>> updated_stored_messages: {len(self.chat_message_history.messages)}')
        logger.info(f'{pp.pformat(self.chat_message_history.messages)}')

        return True
    
    def summarize_old_messages_B(self, chain_input) -> bool:

        stored_messages = self.chat_message_history.messages
        logger.info('================<<chat history summarization>>======================')
        logger.info(f'\n>> stored_messages: {len(stored_messages)}')
        logger.info(f'{pp.pformat(stored_messages)}')

        if len(stored_messages) <= self.max_stored_messages:
            return False
        
        summarization_chain = self.prompts['chat_summarization'] | self.chat_llm

        messages_to_summarize = stored_messages[:CHAT_MESSAGES_TO_SUMMARIZE]
        logger.info(f'\n>> messages_to_summarize: {len(messages_to_summarize)}')
        logger.info(f'{pp.pformat(messages_to_summarize)}')

        summary_message = summarization_chain.invoke({"chat_history": messages_to_summarize})
   
        self.chat_message_history.clear()
        self.chat_message_history.add_user_message("Resume nuestra conversación")
        self.chat_message_history.add_ai_message(summary_message)

        for message in stored_messages[CHAT_MESSAGES_TO_SUMMARIZE:]:
            self.chat_message_history.add_message(message)
        logger.info(f'\n>> updated_stored_messages: {len(self.chat_message_history.messages)}')
        logger.info(f'{pp.pformat(self.chat_message_history.messages)}')

        return True
    
    def reformat_chat_summarization(self, messages_to_summarize) -> str:

        prompt_as_messages = self.prompts['chat_summarization']\
            .format_messages(chat_history=messages_to_summarize)
        
        system_prompt = prompt_as_messages[0]
        conversation = prompt_as_messages[1:]
        
        reformated_prompt = ''
        reformated_prompt += system_prompt.content
        reformated_prompt += "\n\n<conversation>"
        for msg in conversation:
            if isinstance(msg, HumanMessage):
                reformated_prompt += f"\nuser: {msg.content}"
            if isinstance(msg, AIMessage):
                reformated_prompt += f"\nassistant: {msg.content}"
        reformated_prompt += "\n</conversation>"
        
        return reformated_prompt


# %%
# toc 3. Define functions
#========================

#%%
def create_rag_chatbot(config_data_preparation: DictConfig, config_rag_chatbot_engine: DictConfig) -> RAGChatbot:

    chatbot_factory = {
        "RAGChatbotWithMsgDropping": RAGChatbotWithMsgDropping,
        "RAGChatbotWithMsgSummarization": RAGChatbotWithMsgSummarization,
        "RAGChatbotWithFullMemory": RAGChatbotWithFullMemory
    }

    try:
        chatbot = chatbot_factory[config_rag_chatbot_engine.rag_chatbot_type](
                config_data_preparation=config_data_preparation,
                config_rag_chatbot_engine=config_rag_chatbot_engine)
        return chatbot
    
    except Exception as e:

        raise ValueError(f"{config_rag_chatbot_engine.rag_chatbot_type} is not a valid rag_chatbot_type. {e}")
    
#%%
def main() -> None:

    # Create chatbot
    config_data_preparation = OmegaConf.load("params.yaml").data_preparation
    config_rag_chatbot_engine = OmegaConf.load("params.yaml").rag_chatbot_engine
    chatbot = create_rag_chatbot(
        config_data_preparation=config_data_preparation,
        config_rag_chatbot_engine=config_rag_chatbot_engine)

    # Run conversation
    print(f'AI: {chatbot.chat_message_history.messages[-1].content}')
    while True:
        user_input = input("\nuser: ")
        result = chatbot.chat_chain.invoke(
            {"input": user_input},
            {"configurable": {"session_id": "unused"}})
        print(f"\nAI: {result['answer']}")

# %%
if __name__ == "__main__":
    main()










