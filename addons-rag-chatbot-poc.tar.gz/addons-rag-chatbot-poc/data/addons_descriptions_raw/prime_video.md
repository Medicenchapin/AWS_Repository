# Descripción general
- 1 mes cortesia de Tigo, después Q45 al mes.
- Más de 4,000 series y películas
- Acceso a web, app y Smart tv
- Hasta 3 pantallas simultáneas
- Descarga de contenido y aplicación
- Donde quieras, cuando quieras 