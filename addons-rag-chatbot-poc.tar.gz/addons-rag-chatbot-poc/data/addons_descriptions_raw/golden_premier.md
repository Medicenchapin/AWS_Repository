# Descripción general
- Golden Premier: 2 canales /Q30 adicionales
- Golden Premier
- Golden Premier 2 