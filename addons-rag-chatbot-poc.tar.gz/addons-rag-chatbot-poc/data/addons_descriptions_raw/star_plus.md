# Descripción general
- Disfruta de tus series favoritas, estrenos de cine, producciones originales, todas las temporadas de Los Simpson y los deportes en vivo de ESPN por Q99.00 al mes
- Eventos deportivos en directo de máxima calidad por ESPN.
- Disfruta hasta en 4 pantallas simultaneas, al instante.
- Descarga hasta en 10 dispositivos y crea hasta 7 perfiles por cuenta con control parental. 