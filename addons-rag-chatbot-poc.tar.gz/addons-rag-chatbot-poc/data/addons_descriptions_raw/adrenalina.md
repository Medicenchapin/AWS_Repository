# Descripción general
- Adrenalina Sports Network (antes conocido como Fighting Sports Network y UFC Network) es una canal enfocado en deportes extremos y de contacto como MMA, Box, Kickboxing y más.
- Además de presentar eventos en vivo, esta señal ofrece repeticiones de los momentos más emocionantes de estos deportes. 