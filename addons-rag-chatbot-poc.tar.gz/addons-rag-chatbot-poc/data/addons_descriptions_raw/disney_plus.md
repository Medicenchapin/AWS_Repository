# Descripción general
- Primer mes cortesía de Disney+. A partir del mes 2 pagarás Q64.00 al mes.
- Disfruta en 4K de lo mejor de Disney, Pixar, Marvel, Star Wars y National Geographic en un mismo lugar.
- Clásicos inolvidables y nuevos originales de Disney+ todos los meses.
- Disfruta hasta en 4 pantallas simultaneas, al instante.
- Descarga hasta en 10 dispositivos y crea hasta 7 perfiles por cuenta con control parental. 