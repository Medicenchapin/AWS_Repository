# Descripción general
- Prepárate para vivir la experiencia de ViX incluyendo las señales en VIVO de LaLiga Española por sólo Q45 al mes. Todo el detalle en tu factura.
- El Servicio Streaming en español más grande del mundo. Series, películas y deportes premium como LaLiga Española.
- Accede a todos los partidos de LaLiga, a través de app ViX y através del canal ViX | LaLiga con Tigo en los siguientes señales: 001 SD, 701 HD
- hasta 3 dispositivos simultáneamente en la Web y App de ViX 