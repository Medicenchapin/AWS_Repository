# Descripción general
- Prepárate para vivir la experiencia de ViX incluyendo las señales en VIVO de LaLiga Española por sólo Q45 al mes. Todo el detalle en tu factura.
- El Servicio Streaming en español más grande del mundo. Series, películas y deportes premium como LaLiga Española.
- Accede a todos los partidos de LaLiga, a través de app ViX y através del canal ViX | LaLiga con Tigo en los siguientes señales: 001 SD, 701 HD
- hasta 3 dispositivos simultáneamente en la Web y App de ViX 

# Descripción de plataformas

## Vix

### Descripción

Vix es un servicio de streaming hispano propiedad de TelevisaUnivision. Fue relanzada el 31 de marzo de 2022 en México y Estados Unidos, como resultado de la fusión de Blim TV, Univision Now y su plataforma hermana Prende TV. A continuación, un resumen sobre Vix:

<context>
Vix es un servicio de streaming hispano propiedad de TelevisaUnivision, que fue relanzada el 31 de marzo de 2022 en México y en Estados Unidos, como parte de la fusión de Blim TV, Univision Now y su plataforma hermana Prende TV.

Inicialmente, en 2015, Batanga Media lanzó Vix como una plataforma enfocada en la creación y distribución de contenido social a gran escala en tres idiomas. En 2017, Batanga Media, junto con iMujer y Bolsa de Mulher, unificaron su identidad bajo el nombre Vix. En ese entonces, Vix dirigía una comunidad de 88 millones de usuarios en Facebook, Instagram, YouTube y Twitter, siendo una de las plataformas de mayor consumo de video en español y portugués en el mundo. Operaba canales centrados en temas de mujer, salud, cultura pop, geeks, entre otros.

En 2019, Vix fue adquirida por Univision Communications, convirtiéndose en parte de su división de medios digitales. Posteriormente, en 2022, tras la fusión de Univision con Televisa para formar TelevisaUnivision, Vix fue relanzada como un servicio de streaming que integró las plataformas Blim TV, Univision Now y Prende TV.
</context>

**Fuente:**
- https://es.wikipedia.org/wiki/Vix_(servicio_de_streaming)

### Descripción de contenido

<context>
El catálogo de contenido de ViX incluye clásicos de televisión, documentales, series de televisión, películas, programación deportiva y telenovelas de la videoteca de TelevisaUnivision.

ViX consiste en dos planes:

1. Un servicio bajo demanda gratuito con publicidad que alberga 40 mil horas en catálogo, con más de 100 canales líneales temáticos.

2. Un servicio bajo demanda por suscripción pagada sin publicidad, al cual se le añade otras 10 mil horas de contenido prémium y exclusivo, además de contenido original.
</context>

El contenido disponible en ViX es variado. La plataforma ofrece dos planes de suscripción:

En el plan gratuito con publicidad, los usuarios tienen acceso a 40 mil horas de contenido en su catálogo, que incluye clásicos de televisión, documentales, series, películas, programación deportiva y telenovelas de la videoteca de TelevisaUnivision. Además, este plan ofrece más de 100 canales lineales temáticos.

Por otro lado, el plan de suscripción pagada sin publicidad, conocido como ViX+, añade otras 10 mil horas de contenido premium y exclusivo al catálogo, así como contenido original producido específicamente para esta plataforma. De esta manera, ViX+ brinda una oferta más amplia y sin interrupciones publicitarias.

**Fuente:**
- https://es.wikipedia.org/wiki/Vix_(servicio_de_streaming)

### Diferenciador

Según la información proporcionada, la principal diferencia de ViX con otras plataformas de streaming es que ofrece dos versiones: ViX premium (de pago) y ViX gratis (gratuita). A continuación, un resumen de las diferencias clave entre ambas versiones:

<context>
ViX premium es una versión de pago, mientras que ViX gratis es de acceso libre y gratuito. Aunque ambas ofrecen producciones y canales en vivo, existen diferencias sustanciales en el contenido disponible. ViX premium tiene acceso exclusivo a algunos canales importantes de Televisa como el 2, 4, 5 y 9, los cuales no están disponibles en la versión gratuita a pesar de transmitirse en televisión lineal abierta. Además, gran parte del contenido deportivo está bloqueado para usuarios de ViX gratis, siendo exclusivo de la versión premium de pago.
</context>

En resumen, la principal diferencia de ViX radica en ofrecer una versión gratuita con acceso limitado, y una versión premium de pago que brinda acceso completo a todos sus canales y contenidos, incluyendo canales abiertos de Televisa y eventos deportivos que no están disponibles en la versión gratuita. Esta dualidad de opciones gratuita y de pago la distingue de otras plataformas de streaming.

**Fuente:**
- https://www.sdpnoticias.com/tecnologia/vix-premium-y-vix-gratis-las-diferencias-del-servicio-de-streaming-precio-en-2024-y-mas/