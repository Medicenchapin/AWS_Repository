# Descripción general
- 1 mes cortesia de Tigo, después Q45 al mes.
- Más de 4,000 series y películas
- Acceso a web, app y Smart tv
- Hasta 3 pantallas simultáneas
- Descarga de contenido y aplicación
- Donde quieras, cuando quieras 

# Descripción de plataformas

## Prime video

### Descripción

<context>
Prime Video (también comercializado como Amazon Prime Video) es un servicio de streaming OTT de películas y series creado y gestionado por Amazon. Se ofrece tanto como un servicio independiente o como parte de la suscripción a Amazon Prime. El servicio distribuye principalmente películas y series de televisión producidas por Amazon Studios y MGM Holdings o con licencia de Amazon, como las Amazon Originals, y también aloja contenido de otros estudios y redes.

Prime Video ofrece contenido exclusivo y series Amazon Originals. Disfruta películas y series exclusivas como The Grand Tour y títulos premiados como The Man in the High Castle, Mozart in the Jungle y Transparent.

Es un servicio de reproducción en streaming de video ofrecido por Amazon. Los beneficios de Prime Video se incluyen con la membresía Amazon Prime. Con tu membresía, puedes ver cientos de programas y películas en tus dispositivos favoritos. Puedes acceder a Prime Video a través del sitio web Amazon.com/primevideo o descargando la aplicación Prime Video en tu dispositivo móvil.
</context>

Prime Video es un servicio de streaming de video bajo demanda creado y operado por Amazon. Ofrece películas, series de televisión y contenido original exclusivo a los suscriptores de Amazon Prime o como un servicio independiente. Permite ver cientos de títulos en dispositivos compatibles a través de su sitio web o aplicación móvil. Destaca por distribuir producciones originales de Amazon Studios y MGM Holdings, además de contenido licenciado de otros estudios y redes. Es una plataforma de streaming OTT (over-the-top) que compite con servicios similares como Netflix, Hulu, entre otros.

**Fuente:**
- https://www.amazon.com/-/es/gp/video/splash/getTheApp
- https://es.wikipedia.org/wiki/Prime_Video

### Descripción de contenido

<context>
Prime Video ofrece varias formas de ver películas y series:

- Incluido con Prime: Son películas y series que se incluyen como parte de la suscripción a Prime Video. Los clientes pueden reproducir estos títulos sin coste adicional. La selección de títulos "Incluidos con Prime" cambia con el tiempo a medida que se añaden y eliminan contenidos del catálogo.

- Películas y series para comprar o alquilar: Prime Video también ofrece la opción de comprar o alquilar películas y series que no están incluidas en la suscripción.

- Suscripciones de Prime Video: Además de la suscripción principal, Prime Video ofrece suscripciones adicionales a canales de terceros.

En cuanto al catálogo, Prime Video ofrece principalmente contenido original de Amazon Studios y adquisiciones con licencia incluidas en la suscripción. El catálogo es más reducido en comparación con servicios similares, especialmente fuera de los Estados Unidos. Sin embargo, cualquier contenido en Prime Video tiene el potencial de enganchar al espectador, desde series adictivas hasta películas sobre coches y carreras, pasando por series de animación.
</context>

**Fuente:**
- https://www.primevideo.com/-/es/help/ref=atv_hp_nd_nav?nodeId=TLKV1OADtdHSPuczvv
- https://www.lavanguardia.com/andro4all/series/series-peliculas-catalogo-prime-video
- https://es.wikipedia.org/wiki/Prime_Video

### Diferenciador

Según la información proporcionada, no se mencionan diferencias específicas que distinga a Prime Video de otras plataformas de streaming. El texto se enfoca principalmente en hacer una comparación general entre varios servicios de video bajo demanda (VOD) como Disney+, Netflix, HBO, Prime Video, Movistar+ Lite, Filmin, Apple TV y Rakuten TV, analizando aspectos como el catálogo, las funciones y los precios. Sin embargo, no profundiza en detalles que resalten las particularidades de Prime Video frente a sus competidores. Por lo tanto, no puedo generar un resumen que responda directamente a la pregunta planteada debido a la falta de información relevante en el texto proporcionado.

**Fuente:**
- https://es.digitaltrends.com/entretenimiento/netflix-vs-amazon-prime-video/
- https://www.xataka.com/basics/comparativa-disney-netflix-hbo-movistar-prime-video-apple-filmin-catalogo-funciones-precios