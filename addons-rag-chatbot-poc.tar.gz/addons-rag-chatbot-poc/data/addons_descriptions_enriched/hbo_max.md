# Descripción general
- 2 meses cortesia y a partir del mes 3 por Q64 al mes.
- Acceso a la plataforma de streaming HBO + MAX. Disponible en todos tus dispositivos favoritos
- HBO HD
- HBO 2 SD y HD
- HBO Plus + SD y HD
- HBO Signature SD Y HD
- HBO Family HD
- HBO Mundi SD y HD
- HBO POP SD y HD
- HBO Xtreme SD y HD 

# Descripción de plataformas

## Max

### Descripción

<context>
Max (anteriormente conocido y aún denominado HBO Max en algunas regiones) es un servicio de streaming propiedad de Warner Bros. Discovery. Se lanzó en Estados Unidos el 27 de mayo de 2020, en Latinoamérica el 29 de junio de 2021, Andorra, España y los países nórdicos el 26 de octubre de 2021. Es una plataforma de streaming de video bajo demanda por suscripción que ofrece contenido de entretenimiento como películas, series de televisión, documentales y otros programas. Está disponible en varios idiomas, incluyendo español, inglés, portugués, danés, noruego y finlandés. Requiere registro y suscripción para acceder a su catálogo de contenidos.
</context>

**Fuente:**
- https://es.wikipedia.org/wiki/Max_(servicio_de_streaming)
- https://help.max.com/cr-es/answer/detail/000002558

### Descripción de contenido

<context>
Max es una plataforma de streaming de contenido bajo demanda de la mano de la productora WarnerMedia. La aplicación está disponible en smart TV, Android y iOS o puedes utilizar el navegador para entrar en todos los contenidos con tu cuenta de Max/HBO Max. No hay mejor manera para terminar el día de trabajo que poner Max y disfrutar de todo el extenso catálogo que te espera. A veces puede ser muy duro elegir un contenido desechando tantos otros de grandísima calidad.
</context>

Según la información proporcionada, Max ofrece un extenso catálogo de contenido bajo demanda de alta calidad. El texto menciona que la plataforma cuenta con una gran variedad de contenidos, lo que a veces dificulta la elección de qué ver debido a la gran cantidad de opciones disponibles. Max permite a los usuarios disfrutar de su catálogo al final del día laboral, lo que sugiere que ofrece una amplia gama de programas de entretenimiento. En resumen, el contenido disponible en Max es abundante, de calidad y abarca diversos géneros y formatos para satisfacer diferentes gustos y preferencias.

**Fuente:**
- https://www.lavanguardia.com/andro4all/series/hbo-max-catalogo-series-peliculas
- https://www.max.com/gt/es

### Diferenciador

Según la información proporcionada, aquí está un resumen de las diferencias entre Max y otras plataformas de streaming como HBO Max y Netflix:

<context>
Max se diferencia de otras plataformas de streaming en varios aspectos. A diferencia de Netflix, Max no ofrece una opción de suscripción anual, sino únicamente planes de pago mensuales con diferentes niveles de calidad y cantidad de reproducciones simultáneas permitidas. Aunque no permite compartir cuentas de forma gratuita como antes, Max ofrece la posibilidad de añadir hasta dos suscriptores adicionales que no vivan en el mismo hogar, lo que brinda cierta flexibilidad para compartir la cuenta de manera limitada.

Otra diferencia clave es el contenido disponible. Mientras que Netflix se enfoca en su propio catálogo de series y películas originales, Max ofrece un conjunto diferente de contenido que puede ser más atractivo para algunos usuarios según sus preferencias. Tanto Max como Netflix ofrecen calidad de hasta 4K en algunos de sus títulos y contenido infantil.

En cuanto a los precios, Max suele ser más económico que Netflix en sus planes mensuales. Sin embargo, la elección entre ambas plataformas dependerá de los gustos individuales del usuario y el tipo de contenido que busque. Se recomienda considerar ambas opciones y aprovechar la posibilidad de compartir cuentas y crear perfiles para acceder a los catálogos de ambas plataformas.
</context>

**Fuente:**
- https://www.adslzone.net/reportajes/tv-streaming/comparativa-netflix-hbo-max/
- https://www.lavanguardia.com/andro4all/series/diferencias-entre-max-y-hbo-max-todo-lo-que-cambia-y-se-mantiene

## Hbo

### Descripción

<context>
HBO (Home Box Office) es un servicio de televisión por suscripción operado por la compañía estadounidense Warner Bros. Discovery. Fue lanzado originalmente como un canal de televisión por cable premium en 1972. En mayo de 2020, HBO lanzó su plataforma de streaming HBO Max, que ofrecía contenido adicional además de las series y películas de HBO.

En mayo de 2023, HBO Max fue relanzada como Max, una plataforma de streaming que combina el contenido de HBO con otras propiedades de Warner Bros. Discovery. La marca HBO Max fue descontinuada en Estados Unidos y posteriormente en otros países de América Latina y Europa.
</context>

**Fuente:**
- https://es.wikipedia.org/wiki/Max_(servicio_de_streaming)

### Descripción de contenido

<context>
HBO (Home Box Office) es un servicio de televisión por suscripción que ofrece una amplia variedad de contenido, incluyendo series de drama, ciencia ficción, fantasía y programas para niños y familias. Además de su programación original, HBO también transmite películas y otros programas adquiridos.

En Latinoamérica, HBO tiene una presencia regional con canales y servicios de streaming adaptados a los diferentes mercados. Por otro lado, HBO Europe y HBO España/Portugal son operaciones separadas que ofrecen contenido localizado para esas regiones.

Aunque HBO es conocido por su programación de alta calidad, el acceso a su contenido puede variar dependiendo de la región y el método de distribución utilizado, como cable, streaming o DVD. En algunos casos, los espectadores pueden tener que esperar meses o incluso años para ver ciertos programas o películas después de su transmisión original en HBO.
</context>

HBO ofrece una amplia variedad de contenido de alta calidad a través de sus diferentes plataformas y canales regionales. Su programación incluye series de drama, ciencia ficción, fantasía y contenido familiar. Aunque el acceso al contenido puede variar según la región y el método de distribución, HBO se destaca por su oferta de programación original y adquirida.

**Fuente:**
- https://es.wikipedia.org/wiki/HBO
- https://www.lavanguardia.com/andro4all/series/hbo-max-catalogo-series-peliculas

### Diferenciador

Según la información proporcionada, aquí está un resumen de las diferencias clave entre HBO y otras plataformas de streaming:

<context>
HBO se destaca por su catálogo de series y películas originales de alta calidad y prestigio. Ofrece producciones galardonadas y aclamadas por la crítica como Game of Thrones, Succession, The Last of Us, entre otras. Su enfoque está en el contenido premium y exclusivo.

Además, HBO permite crear hasta 5 perfiles de usuario diferentes dentro de una misma suscripción. Esto permite personalizar las recomendaciones y continuar viendo contenido desde donde se dejó para cada miembro de la familia.

En cuanto a la calidad de video, HBO ofrece streaming en resoluciones de hasta 4K HDR en ciertos títulos, brindando una experiencia visual de alta gama. También cuenta con funciones como descargas para ver contenido sin conexión y compatibilidad con los principales dispositivos y plataformas.
</context>

**Fuente:**
- https://comparaiso.es/comparativas/netflix-hbo-mejor-plataforma-streaming
- https://www.xataka.com/basics/comparativa-disney-netflix-hbo-movistar-prime-video-apple-filmin-catalogo-funciones-precios