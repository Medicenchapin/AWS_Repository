# Descripción general
- Primer mes cortesía de Disney+. A partir del mes 2 pagarás Q64.00 al mes.
- Disfruta en 4K de lo mejor de Disney, Pixar, Marvel, Star Wars y National Geographic en un mismo lugar.
- Clásicos inolvidables y nuevos originales de Disney+ todos los meses.
- Disfruta hasta en 4 pantallas simultaneas, al instante.
- Descarga hasta en 10 dispositivos y crea hasta 7 perfiles por cuenta con control parental. 

# Descripción de plataformas

## Disney plus

### Descripción

<context>
Disney+ (Disney Plus) es un servicio de streaming propiedad de The Walt Disney Company mediante su división Disney Entertainment. El servicio ofrece películas, documentales, especiales, cortos, eventos en vivo, programas y series de televisión producidos por The Walt Disney Studios y Disney General Entertainment Content. Su interfaz presenta diferentes secciones temáticas con contenidos de Disney, Pixar, Marvel, Star Wars, National Geographic y otros estudios y productoras propiedad de Disney.
</context>

Disney+ es un servicio de streaming de video por suscripción operado por Disney Streaming, una subsidiaria de The Walt Disney Company. Ofrece una amplia variedad de contenido multimedia producido por los estudios y productoras propiedad de Disney, incluyendo películas, series de televisión, documentales, cortos y especiales. La plataforma está organizada en secciones temáticas que agrupan el contenido de marcas como Disney, Pixar, Marvel, Star Wars y National Geographic. Disney+ se lanzó en noviembre de 2019 y actualmente se encuentra disponible en varios países alrededor del mundo.

**Fuente:**
- https://es.wikipedia.org/wiki/Disney%2B

### Descripción de contenido

<context>
Disney Plus ofrece un amplio catálogo de contenido que incluye:

- Series como The Simpsons, Garfield, la saga Ice Age y Solo en Casa.
- Películas y cortometrajes de Disney.
- Series de Disney.
- Películas y cortometrajes de Pixar.
- Películas y series de Marvel.
- Películas, series y especiales de Star Wars.
- Películas, series y especiales de National Geographic.
- Otros documentales y contenido especial.

Disney Plus es una plataforma de streaming que reúne una gran variedad de producciones de las marcas propiedad de The Walt Disney Company, abarcando animación, acción en vivo, documentales y más. Ofrece un vasto catálogo de contenido para disfrutar de clásicos y nuevos lanzamientos de estas reconocidas franquicias.
</context>

**Fuente:**
- https://es.wikipedia.org/wiki/Disney%2B
- https://www.lavanguardia.com/andro4all/series/disney-plus-catalogo-series-peliculas-disponibles-espana

### Diferenciador

Según la información proporcionada, lo que diferencia a Disney+ de otras plataformas de streaming es:

<context>
Disney+ destaca por tener en ella sus principales franquicias, con contenido como los clásicos de Disney, Pixar, Marvel, Star Wars y National Geographic y Star. Es el servicio que más perfiles permite crear para compartir, y su precio es bastante contenido.
</context>

Disney+ se distingue por ofrecer el catálogo de contenidos de las principales franquicias propiedad de Disney, como las películas clásicas de Disney, las producciones de Pixar, las películas del universo Marvel, la saga de Star Wars y los documentales de National Geographic. Además, permite crear un mayor número de perfiles de usuario para compartir la suscripción en comparación con otros servicios. Por otro lado, su precio es relativamente bajo en comparación con la competencia.

**Fuente:**
- https://www.xataka.com/basics/comparativa-disney-netflix-hbo-movistar-prime-video-apple-filmin-catalogo-funciones-precios