# Quickstart

__NOTA:__ El proyecto se desarrolló usando el subsistema de Windows para Linux (WSL2). Se recomienda que los usuarios de Windows trabajen en este entorno para tener mayor compatibilidad.

1. Prerequisitos: 

    - [Instalar WSL2](https://learn.microsoft.com/en-us/windows/wsl/install) (Solo para usuarios de Windows)
    - [Instalar AWS CLI](https://docs.aws.amazon.com/cli/latest/userguide/cli-chap-getting-started.html)
    - [Instalar git](https://git-scm.com/book/en/v2/Getting-Started-Installing-Git)
    - [Instalar git-remote-codecommit](https://docs.aws.amazon.com/codecommit/latest/userguide/setting-up-git-remote-codecommit.html)
    - Instalar python (3.10 <= version <= 3.12)

1. Abrir la consola, crear un directorio para el proyecto y abrirlo. (Windows: Abrir la consola de WSL2)
    ```
    mkdir gt-addons-rag-chatbot-poc
    cd gt-addons-rag-chatbot-poc
    ```

1. Iniciar sesión en AWS usando SSO
    ```
    aws sso login --profile xxxxxxxxxxxxxx
    ```

1. Definir el perfil a usar por defecto usando una variable de entorno
    ```
    export AWS_DEFAULT_PROFILE=xxxxxxxxxxxxxx
    ```

1. Clonar repositorio usando HTTPS(GRC)
    ```
    git clone codecommit::us-east-1://addons-rag-chatbot-poc .
    ```

1. Iniciar VS Code
    ```
    code .
    ```

1. Crear entorno virtual de python usando venv
    ```
    python -m venv .venv
    ```

1. Usar entorno virtual
    ```
    source .venv/bin/activate
    ```

1. Instalar dependencias usando el archivo requirements .txt
    ```
    pip install -r requirements.txt
    ```

1. Crear archivo .env y agregar variables de entorno
    ```
    AWS_DEFAULT_PROFILE=xxxxxxxxxxxxxx
    AWS_DEFAULT_REGION=xxxxxx
    SERPER_API_KEY=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

    LANGCHAIN_TRACING_V2="true"
    LANGCHAIN_API_KEY=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
    OPENAI_API_KEY=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

    ROOT_WORKING_DIRECTORY=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
    ```

1. Crear rama de desarrollo local
    ```
    git checkout -b dev
    ```

1. Probar funcionamiento usando streamlit
    ```
    streamlit run src/ChatbotGUI.py
    ```

